package com.jut.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jut.entity.Employee;
import com.jut.service.EmpService;
import com.jut.utility.UserValidation;

@Controller
public class EmployeeController {
	@Autowired
	EmpService service;

	@Autowired
	UserValidation userValidation;


	@RequestMapping("/requestToHrForLeave")
	public String register(@ModelAttribute Employee e, Model model, HttpSession session) {
		String user = userValidation.validate(session);
		e.setHrEmail(user);
		if (user == null) {
			return "login";
		}
		boolean isAdded = service.register(e);
		if (isAdded)
			model.addAttribute("msg", "Employee Register Successfully");
		else
			model.addAttribute("msg", "Unable to Register");

		return "hrDashboard";
	}
	
}
