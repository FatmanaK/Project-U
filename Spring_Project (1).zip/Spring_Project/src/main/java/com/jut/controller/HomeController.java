package com.jut.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/forgotPasswordPage")
	public String forgotPassword(){
		return "forgotPassword";
	}

	@RequestMapping("/")
	public String login(){
		return "login";
	}

	@RequestMapping("/backToLoginPage")
	public String backToLoginPage(){
		return "login";
	}
	
	@RequestMapping("/hrDashboard")
	public String hrDashboard() {
		return "hrDashboard";
	}
	
	@RequestMapping("/allEmployee")
	public String allEmployee() {
		return "allEmployee";
	}
	
	@RequestMapping("/employeeDashboard")
	public String employeeDashboard() {
		return "empDashboard";
	}
	
	@RequestMapping("/dropLeaveHere")
	public String dropLeaveHere() {
		return "employeeLeaveDropForm";
	}

}
