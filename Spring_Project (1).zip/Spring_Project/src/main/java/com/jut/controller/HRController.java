package com.jut.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jut.entity.Employee;
import com.jut.service.EmpService;
import com.jut.utility.UserValidation;

@Controller
public class HRController {
	@Autowired
	EmpService service;

	@Autowired
	UserValidation userValidation;

	@RequestMapping("/register")
	public String register(@ModelAttribute Employee e, Model model, HttpSession session) {
		boolean isValid = userValidation.validateHr(session);
		String user = (String) session.getAttribute("user");
		e.setHrEmail(user);
		if (!isValid) {
			return "login";
		}
		boolean isAdded = service.register(e);
		if (isAdded)
			model.addAttribute("msg", "Employee Register Successfully");
		else
			model.addAttribute("msg", "Unable to Register");

		return "hrDashboard";
	}

	@RequestMapping("/profilePage")
	public String getProfile(Model model, HttpSession session) {
		String user = userValidation.validate(session);
		if (user == null) {
			return "login";
		}
		List<Employee> names = service.profilePageDetails(user);
		model.addAttribute("data", names);
		return "employeeProfile";
	}

	@RequestMapping("/employeeProfile")
	public String employeeProfileDetails(@RequestParam("name") String name, Model model, HttpSession session) {
		String user = userValidation.validate(session);
		if (user == null) {
			return "login";
		}
		Employee employee = service.employeeProfileDetails(name);
		List<Employee> names = service.profilePageDetails(user);
		model.addAttribute("data", names);
		model.addAttribute("empDetails", employee);
		return "employeeProfile";
	}

	@RequestMapping("/allEmployeeDetails")
	public String allEmployeeDetails(Model model, HttpSession session) {
		String user = userValidation.validate(session);
		if (user == null) {
			return "login";
		}
		List<Employee> emp = service.allEmployeeDetails(user);
		model.addAttribute("empDetails", emp);
		return "allEmployeeDetails";
	}

	@RequestMapping("/employeeSalarySheet")
	public String employeeSalarySheet(Model model, HttpSession session) {
		String user = userValidation.validate(session);
		if (user == null) {
			return "login";
		}
		List<Employee> emp = service.employeeSalarySheet();
		model.addAttribute("empDetails", emp);
		return "employeeSalaryDetails";
	}

	@RequestMapping("/updateEmpProfile")
	public String getEmployeeDetailsForUpdate(@RequestParam("empId") int id, Model model) {
		Employee e = service.getEmployeeDetailsForUpdate(id);
		model.addAttribute("updateEmp", e);
		return "updateEmployeeForm";
	}

	@RequestMapping("/updateEmpSalary")
	public String getEmployeeDetailsForSalaryUpadate(@RequestParam("empId") int id, Model model) {
		Employee e = service.getEmployeeDetailsForSalaryUpadate(id);
		model.addAttribute("updateEmpSalary", e);
		return "updateEmpSalaryForm";
	}

	@RequestMapping("/getEmployeeDetailsForUpdate")
	public String updateEmpProfile(@ModelAttribute Employee e, Model model) {
		boolean isUpdated = service.updateEmpProfile(e);
		if (isUpdated)
			model.addAttribute("msg", "Employee Data Updated Successfully");
		else
			model.addAttribute("msg", "Unable to Update");

		return "allEmployeeDetails";
	}

	@RequestMapping("/getEmployeeDetailsForSalaryUpdate")
	public String updateEmpSalary(@ModelAttribute Employee e, Model model) {
		boolean isUpdated = service.updateEmpSalary(e);
		if (isUpdated){
			List<Employee> emp = service.employeeSalarySheet();
			model.addAttribute("empDetails", emp);
			model.addAttribute("msg", "Employee Salary Updated Successfully");
		}
		else
			model.addAttribute("msg", "Unable to Update");

		return "employeeSalaryDetails";
	}

	@RequestMapping("/deleteEmployee")
	public String deleteEmployeeById(@RequestParam("empId") int id, Model model) {
		boolean isDeleted = service.deleteEmployeeById(id);
		if (isDeleted)
			model.addAttribute("msg", "Employee Deleted Successfully");
		else
			model.addAttribute("msg", "Unable to Delete");

		return "allEmployeeDetails";
	}

}
