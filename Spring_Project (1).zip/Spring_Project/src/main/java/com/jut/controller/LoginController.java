package com.jut.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.jut.dao.EmpDao;

@Controller
public class LoginController {
	@Autowired
	EmpDao dao;

	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String hrLogin(@RequestParam("email") String email, @RequestParam("password") String password, Model model,
			HttpSession session) {
		boolean isValid = dao.login(email, password);
		if (isValid) {
			String role = dao.findRole(email);
			session.setAttribute("user", email);
			session.setAttribute("role", role);
			if (role != null) {
				if (role.equalsIgnoreCase("HR"))
					return "hrDashboard";
				else
					return "empDashboard";
			}
		}
			model.addAttribute("msg", "Invalid credentials");
			return "login";
	}

	@RequestMapping(value = "/checkValidUser", method = RequestMethod.POST)
	public String forgotPassword(@RequestParam("email") String email, Model model) {
		boolean isValid = dao.forgotPassword(email);
		if (isValid) {
			model.addAttribute("msg", "Enter your registered email and new password");
			return "newPassword";
		} else {
			model.addAttribute("msg", "Enter valid email");
			return "forgotPassword";

		}
	}

	@RequestMapping(value = "/newPassword", method = RequestMethod.POST)
	public String newPassword(@RequestParam("email") String email, @RequestParam("password") String password,
			Model model) {
		boolean isUpdated = dao.newPassword(email, password);
		if (isUpdated) {
			model.addAttribute("msg", "Password Updated Successfully");
			return "login";
		} else {
			model.addAttribute("msg", "Enter your registered email");
			return "newPassword";

		}
	}
}
