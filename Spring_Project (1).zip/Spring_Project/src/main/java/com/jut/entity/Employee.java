package com.jut.entity;

public class Employee {
	private int id;
	private String firstName;
	private String lastName;
	private String employeeType;
	private String designation;
	private String email;
	private String mobNo;
	private String dob;
	private String gender;
	private String userRole;
	private String technology;
	private String hrEmail;
	private float basicSalary;
	private float specialAllowance;
	private float gross;
	private float providentFund;
	private float professionalTax;
	private float totalDeduction;
	private float totalCTC;
	private String totalLeaveDays;
	private String leaveFromDate;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String firstName, String lastName, String employeeType, String designation, String email,
			String mobNo, String dob, String gender, String userRole, String technology, String hrEmail) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeType = employeeType;
		this.designation = designation;
		this.email = email;
		this.mobNo = mobNo;
		this.dob = dob;
		this.gender = gender;
		this.userRole = userRole;
		this.technology = technology;
		this.hrEmail = hrEmail;
	}

	public Employee(int id, String firstName, String lastName, String employeeType, String designation, String email,
			String mobNo, String dob, String gender, String userRole, String technology, String hrEmail,
			float basicSalary, float specialAllowance, float gross, float providentFund, float professionalTax,
			float totalDeduction, float totalCTC) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeType = employeeType;
		this.designation = designation;
		this.email = email;
		this.mobNo = mobNo;
		this.dob = dob;
		this.gender = gender;
		this.userRole = userRole;
		this.technology = technology;
		this.hrEmail = hrEmail;
		this.basicSalary = basicSalary;
		this.specialAllowance = specialAllowance;
		this.gross = gross;
		this.providentFund = providentFund;
		this.professionalTax = professionalTax;
		this.totalDeduction = totalDeduction;
		this.totalCTC = totalCTC;
	}

	public Employee(int id,String firstName, String lastName, String employeeType, float basicSalary, float specialAllowance,
			float gross, float providentFund, float professionalTax, float totalDeduction, float totalCTC) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeType = employeeType;
		this.basicSalary = basicSalary;
		this.specialAllowance = specialAllowance;
		this.gross = gross;
		this.providentFund = providentFund;
		this.professionalTax = professionalTax;
		this.totalDeduction = totalDeduction;
		this.totalCTC = totalCTC;
	}

	public Employee(int id, float basicSalary, float specialAllowance, float gross, float providentFund, float professionalTax,
			float totalDeduction, float totalCTC) {

		this.id = id;
		this.basicSalary = basicSalary;
		this.specialAllowance = specialAllowance;
		this.gross = gross;
		this.providentFund = providentFund;
		this.professionalTax = professionalTax;
		this.totalDeduction = totalDeduction;
		this.totalCTC = totalCTC;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getHrEmail() {
		return hrEmail;
	}

	public void setHrEmail(String hrEmail) {
		this.hrEmail = hrEmail;
	}

	public float getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}

	public float getSpecialAllowance() {
		return specialAllowance;
	}

	public void setSpecialAllowance(float specialAllowance) {
		this.specialAllowance = specialAllowance;
	}

	public float getGross() {
		return gross;
	}

	public void setGross(float gross) {
		this.gross = gross;
	}

	public float getProvidentFund() {
		return providentFund;
	}

	public void setProvidentFund(float providentFund) {
		this.providentFund = providentFund;
	}

	public float getProfessionalTax() {
		return professionalTax;
	}

	public void setProfessionalTax(float professionalTax) {
		this.professionalTax = professionalTax;
	}

	public float getTotalDeduction() {
		return totalDeduction;
	}

	public void setTotalDeduction(float totalDeduction) {
		this.totalDeduction = totalDeduction;
	}

	public float getTotalCTC() {
		return totalCTC;
	}

	public void setTotalCTC(float totalCTC) {
		this.totalCTC = totalCTC;
	}

}
