package com.jut.utility;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;

@Component
public class UserValidation {
	public String validate(HttpSession session){
		String user = null;
		if(session != null){
			user = (String) session.getAttribute("user");
		}
		return user;
	}
	
	public boolean validateHr(HttpSession session){
		String user = null;
		if(session != null){
			user = (String) session.getAttribute("user");
		}
		if(user!=null){
			String role = (String) session.getAttribute("role");
			if(role.equalsIgnoreCase("HR")) return true;
			else  return false;
		}
		return false;
	}
}
