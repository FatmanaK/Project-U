package com.jut.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jut.entity.Employee;

@Repository
public class EmpDao {
	@Autowired
	JdbcTemplate template;

	public boolean register(Employee e) {
		try {
			Object[] args = { e.getFirstName(), e.getLastName(), e.getEmployeeType(), e.getDesignation(), e.getEmail(),
					e.getMobNo(), e.getDob(), e.getGender(), e.getUserRole(), e.getTechnology(), e.getHrEmail() };
			int result = template.update(
					"insert into employee(firstName,lastName,employeeType,designation,email,mobNo,dob,gender,userRole,technology,hrEmail) values(?,?,?,?,?,?,?,?,?,?,?)",
					args);

			int maxId = template.queryForObject("select max(Id) as maxId from employee", new RowMapper<Integer>() {

				public Integer mapRow(ResultSet rs, int arg1) throws SQLException {
					int maxId = rs.getInt("maxId");
					return maxId;
				}

			});

			Object[] args1 = { e.getBasicSalary(), e.getSpecialAllowance(), maxId, e.getGross(), e.getProvidentFund(),
					e.getProfessionalTax(), e.getTotalDeduction(), e.getTotalCTC() };
			int result1 = template.update(
					"insert into salaryDetails(basicSalary,specialAllowance,empId,gross,providentFund,professionalTax,totalDeduction,totalCTC) values(?,?,?,?,?,?,?,?)",
					args1);

			if (result1 == 1)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public List<Employee> profilePageDetails(String user) {
		Object[] args = { user };
		List<Employee> al = template.query("select * from employee where hrEmail=?", args, new RowMapper<Employee>() {
			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {

				Employee e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12));
				return e;

			}
		});
		return al;
	}

	public Employee employeeProfileDetails(String[] names) {
		Object[] args = { names[0], names[1] };
		Employee e = template.queryForObject("select * from employee where firstName = ? and lastName=?", args,
				new RowMapper<Employee>() {

					public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
						Employee e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
								rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
								rs.getString(10), rs.getString(11), rs.getString(12));
						return e;
					}
				});
		return e;
	}

	public List<Employee> allEmployeeDetails(String user) {
		System.out.println("Dao Called");
		Object[] args = { user };
		List<Employee> al = template.query("select * from employee where hrEmail=?", args, new RowMapper<Employee>() {
			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {

				Employee e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12));
				return e;

			}
		});
		return al;
	}

	public Employee getEmployeeDetailsForUpdate(int id) {
		Object[] args = { id };
		Employee e = template.queryForObject("select * from employee where id = ?", args, new RowMapper<Employee>() {
			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {

				Employee e = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12));
				return e;

			}
		});
		return e;
	}

	public boolean updateEmpProfile(Employee e) {
		try {
			Object[] args = { e.getFirstName(), e.getLastName(), e.getEmployeeType(), e.getDesignation(), e.getEmail(),
					e.getMobNo(), e.getDob(), e.getGender(), e.getUserRole(), e.getTechnology(), e.getId() };
			int result = template.update(
					"update employee set firstName = ?,lastName = ?,employeeType = ?,designation = ?,email = ?,mobNo = ?,dob = ?,gender = ?,userRole = ?,technology = ? where id = ?",
					args);
			if (result == 1)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;

	}

	public boolean deleteEmployeeById(int id) {
		try {
			Object[] args = { id };
			int result = template.update("delete from employee where id = ?", args);
			if (result == 1)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public boolean login(String username, String password) {
		try {
			Integer count = 0;
			Object[] args = { username, password };
			count = template.queryForObject("select count(*) from login where username=? and password=?", args,
					new RowMapper<Integer>() {

						public Integer mapRow(ResultSet rs, int arg1) throws SQLException {
							return rs.getInt(1);
						}
					});
			if (count == 1)
				return true;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return false;
	}

	public boolean forgotPassword(String email) {
		try {
			Integer count = 0;
			Object[] args = { email };
			count = template.queryForObject("select count(*) from login where email=?", args,
					new RowMapper<Integer>() {

						public Integer mapRow(ResultSet rs, int arg1) throws SQLException {
							return rs.getInt(1);
						}
					});
			if (count == 1)
				return true;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return false;
	}

	public boolean newPassword(String email, String password) {
		try {
			Object[] args = { password, email };
			int result = template.update("update login set password = ? where email = ?", args);
			if (result == 1)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public List<Employee> employeeSalarySheet() {
		List<Employee> al = template.query(
				"select * from employee ,salaryDetails where employee.Id = salaryDetails.empId",
				new RowMapper<Employee>() {
					public Employee mapRow(ResultSet rs, int arg1) throws SQLException {

						Employee e = new Employee(rs.getInt("id"), rs.getString("firstName"), rs.getString("lastName"),
								rs.getString("employeeType"), rs.getFloat("basicSalary"),
								rs.getFloat("specialAllowance"), rs.getFloat("gross"), rs.getFloat("providentFund"),
								rs.getFloat("professionalTax"), rs.getFloat("totalDeduction"), rs.getFloat("totalCTC"));
						return e;

					}
				});
		return al;
	}

	public Employee getEmployeeDetailsForSalaryUpadate(int id) {
		System.out.println(id);
		Employee e = template.queryForObject("select * from salaryDetails where empId = " + id,
				new RowMapper<Employee>() {
					public Employee mapRow(ResultSet rs, int arg1) throws SQLException {

						Employee e = new Employee(rs.getInt("id"), rs.getFloat("basicSalary"), rs.getFloat("specialAllowance"),
								rs.getFloat("gross"), rs.getFloat("providentFund"), rs.getFloat("professionalTax"),
								rs.getFloat("totalDeduction"), rs.getFloat("totalCTC"));
						return e;

					}
				});
		return e;

	}

	public boolean updateEmpSalary(Employee e) {
		try {
			Object[] args = { e.getBasicSalary(), e.getSpecialAllowance(), e.getGross(), e.getProvidentFund(),
					e.getProfessionalTax(), e.getTotalDeduction(), e.getTotalCTC(), e.getId() };
			int result = template.update(
					"update salaryDetails set basicSalary = ?, specialAllowance = ?, gross = ?, providentFund = ?, professionalTax = ?, totalDeduction = ?, totalCTC = ? where id = ?",
					args);
			if (result == 1)
				return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public String findRole(String email) {
		try {
			Object[] args = {email};
			String role = template.queryForObject("select userRole from employee where email=?", args,new RowMapper<String>(){

				public String mapRow(ResultSet rs, int arg1) throws SQLException {
					return rs.getString("userRole");
				}});
			return role;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
