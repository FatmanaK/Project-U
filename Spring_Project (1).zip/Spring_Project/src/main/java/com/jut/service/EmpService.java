package com.jut.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jut.dao.EmpDao;
import com.jut.entity.Employee;

@Service
public class EmpService {
	@Autowired
	EmpDao dao;

	public boolean register(Employee e) {
		float gross = e.getBasicSalary() + e.getSpecialAllowance();
		float professionalTax = gross / 200;
		float totalDeduction = e.getProvidentFund() + professionalTax;
		float totalCTC = gross - totalDeduction;
		e.setGross(gross);
		e.setProfessionalTax(professionalTax);
		e.setTotalDeduction(totalDeduction);
		e.setTotalCTC(totalCTC);
		return dao.register(e);
	}

	public List<Employee> profilePageDetails(String user) {
		return dao.profilePageDetails(user);
	}

	public Employee employeeProfileDetails(String name) {
		String[] names = name.split(" ");
		return dao.employeeProfileDetails(names);
	}

	public List<Employee> allEmployeeDetails(String user) {
		return dao.allEmployeeDetails(user);
	}

	public Employee getEmployeeDetailsForUpdate(int id) {
		return dao.getEmployeeDetailsForUpdate(id);
	}

	public boolean updateEmpProfile(Employee e) {
		return dao.updateEmpProfile(e);
	}

	public boolean deleteEmployeeById(int id) {
		return dao.deleteEmployeeById(id);
	}

	public List<Employee> employeeSalarySheet() {
		return dao.employeeSalarySheet();
	}

	public Employee getEmployeeDetailsForSalaryUpadate(int id) {
		return dao.getEmployeeDetailsForSalaryUpadate(id);

	}

	public boolean updateEmpSalary(Employee e) {
		float gross = e.getBasicSalary() + e.getSpecialAllowance();
		float professionalTax = gross / 200;
		float totalDeduction = e.getProvidentFund() + professionalTax;
		float totalCTC = gross - totalDeduction;
		e.setGross(gross);
		e.setProfessionalTax(professionalTax);
		e.setTotalDeduction(totalDeduction);
		e.setTotalCTC(totalCTC);
		return dao.updateEmpSalary(e);
	}

}
